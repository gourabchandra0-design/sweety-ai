package com.gourav.sweetyai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.widget.*
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private var recognizer: SpeechRecognizer? = null
    private lateinit var tts: TextToSpeech
    private lateinit var status: TextView
    private lateinit var result: TextView
    private lateinit var language: Spinner
    private var ttsReady = false

    private val languages = listOf(
        "বাংলা" to Locale("bn", "IN"),
        "हिन्दी" to Locale("hi", "IN"),
        "English" to Locale.US
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 36)
        }
        val title = TextView(this).apply {
            text = "SWEETY AI"
            textSize = 30f
        }
        status = TextView(this).apply { text = "তোমার ব্যক্তিগত ভয়েস অ্যাসিস্ট্যান্ট"; textSize = 16f }
        language = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                languages.map { it.first })
        }
        val listen = Button(this).apply {
            text = "🎙 কথা বলো"
            setOnClickListener { startListening() }
        }
        result = TextView(this).apply { text = "তোমার কথা এখানে দেখা যাবে"; textSize = 18f }
        val speak = Button(this).apply {
            text = "উত্তর শোনো"
            setOnClickListener {
                if (result.text.isNotBlank()) speakOut(result.text.toString())
            }
        }
        layout.addView(title); layout.addView(status); layout.addView(language)
        layout.addView(listen); layout.addView(result); layout.addView(speak)
        setContentView(layout)

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 10)
        }
    }

    override fun onInit(code: Int) {
        ttsReady = code == TextToSpeech.SUCCESS
        if (ttsReady) setTtsLanguage()
    }

    private fun selectedLocale(): Locale = languages[language.selectedItemPosition].second

    private fun setTtsLanguage() {
        val availability = tts.setLanguage(selectedLocale())
        status.text = if (availability >= TextToSpeech.LANG_AVAILABLE)
            "সুইটি প্রস্তুত • ${languages[language.selectedItemPosition].first}"
        else "এই ভাষার ভয়েস তোমার TTS ইঞ্জিনে ইনস্টল নেই।"
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "এই ফোনে Speech Recognition পরিষেবা পাওয়া যাচ্ছে না।"
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { status.text = "শুনছি…" }
            override fun onResults(results: Bundle?) {
                val words = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val spoken = words?.firstOrNull().orEmpty()
                result.text = spoken
                status.text = "শোনা শেষ"
                handleCommand(spoken)
            }
            override fun onError(error: Int) { status.text = "শোনা যায়নি (ত্রুটি $error)। আবার চেষ্টা করো।" }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, selectedLocale().toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        recognizer?.startListening(intent)
    }

    private fun handleCommand(text: String) {
        val lower = text.lowercase()
        val reply = when {
            lower.contains("সময়") || lower.contains("time") || lower.contains("समय") ->
                "এখন সময় ${java.text.SimpleDateFormat("hh:mm a", Locale.getDefault()).format(java.util.Date())}"
            lower.contains("তারিখ") || lower.contains("date") || lower.contains("तारीख") ->
                "আজ ${java.text.SimpleDateFormat("dd MMMM yyyy", Locale.getDefault()).format(java.util.Date())}"
            lower.contains("খুলে") || lower.contains("open") || lower.contains("खोलो") ->
                "কোন অ্যাপটি খুলতে চাও? অ্যাপ খোলার অনুমতি ও নির্দিষ্ট কমান্ড পরের সংস্করণে যোগ করা হবে।"
            else ->
                "তোমার কথা শুনেছি: $text। সাধারণ প্রশ্নের বুদ্ধিমান অফলাইন উত্তর দিতে পরের ধাপে ফোনে একটি AI মডেল যুক্ত করতে হবে।"
        }
        result.text = reply
        speakOut(reply)
    }

    private fun speakOut(text: String) {
        if (ttsReady) {
            setTtsLanguage()
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "sweety_reply")
        }
    }

    override fun onDestroy() {
        recognizer?.destroy()
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }
}
