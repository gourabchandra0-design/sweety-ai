SWEETY AI — Android starter project

এই প্রাথমিক প্রজেক্টে আছে:
- বাংলা / হিন্দি / ইংরেজি ভাষা নির্বাচন
- Android SpeechRecognizer দিয়ে ভয়েস ইনপুট
- Android TextToSpeech দিয়ে ভয়েস আউটপুট
- সময় ও তারিখের কয়েকটি স্থানীয় কমান্ড
- EXTRA_PREFER_OFFLINE=true দিয়ে অফলাইন রিকগনিশন পছন্দের অনুরোধ

গুরুত্বপূর্ণ সীমাবদ্ধতা:
1. EXTRA_PREFER_OFFLINE একটি অনুরোধ; ফোনে সংশ্লিষ্ট ভাষার অফলাইন speech pack ও সমর্থিত recognition service থাকতে হবে।
2. Text-to-Speech-এর জন্য Android-এর TTS engine-এ সংশ্লিষ্ট ভাষার voice data ইনস্টল থাকতে হবে।
3. এই starter এখনো পূর্ণ offline LLM নয়। যেকোনো সাধারণ প্রশ্নের বুদ্ধিমান অফলাইন উত্তর দিতে আলাদা on-device model (যেমন উপযুক্ত GGUF মডেল) এবং inference runtime যুক্ত করতে হবে।
4. সব ভাষায় offline speech recognition/TTS সব ফোনে পাওয়া যায় না।
5. "Hey Sweety" সবসময় ব্যাকগ্রাউন্ডে শোনার hotword ফিচার এই starter-এ নেই। Android-এর ব্যাটারি, microphone ও background restrictions মেনে আলাদা foreground service/সম্ভব হলে wake-word engine লাগবে।

খোলার নিয়ম:
- Android Studio-তে এই ফোল্ডার Open করো।
- Gradle sync সম্পন্ন করো।
- ফোনে USB debugging চালু করে Run করো।
- প্রথমবার Microphone permission দাও।
- ফোনের Settings > Languages / Speech services-এ বাংলা, हिन्दी, English offline speech এবং TTS voice থাকলে ডাউনলোড করো।

এটি source-code starter; প্রস্তুত APK নয়। Android Studio দিয়ে build করতে হবে।
